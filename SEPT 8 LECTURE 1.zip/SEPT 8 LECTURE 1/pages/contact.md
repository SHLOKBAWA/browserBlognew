contact
========

I am Shlok Bawa, a software developer. You can contact me by:

Email: sbawa1629@conestogac.on.ca
______

Personal Address: 
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2896.1450064236715!2d-80.55163158464035!3d43.45756977912855!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882bf6a20271bbb9%3A0xd99782a514147d2d!2s380%20Vogel%20Pl%2C%20Waterloo%2C%20ON%20N2L%205V8!5e0!3m2!1sen!2sca!4v1599879685621!5m2!1sen!2sca" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
