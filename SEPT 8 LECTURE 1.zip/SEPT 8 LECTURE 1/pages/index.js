export default [
{"title":"index", "fname":"index.md"},
{"title":"about", "fname":"about.md"},
{"title":"contact", "fname":"contact.md"}
];